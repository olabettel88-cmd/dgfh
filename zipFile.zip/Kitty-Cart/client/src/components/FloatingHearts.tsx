export function FloatingHearts() {
  return null;
}
