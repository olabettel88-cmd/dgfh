## Packages
framer-motion | For smooth page transitions and floating animations
lucide-react | For beautiful icons
canvas-confetti | For the celebration effect on order success

## Notes
Integration with backend API for creating orders.
The design uses a custom "cute" aesthetic with specific pink color palette.
